public class CommandLineArgumentsTaskTwo {
        public static void main(String[] args) {
            int Id = Integer.parseInt(args[0]);
            String Name = String.valueOf(args[1]);

            System.out.println("Your Id is " + Id + " Your Name is " + Name);
    }
}
