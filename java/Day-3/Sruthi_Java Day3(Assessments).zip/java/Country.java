public interface Country {
    public String Population();
    public String Citizens();
}
