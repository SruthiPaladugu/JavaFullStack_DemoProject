public class India implements Country{
    @Override
    public String Population() {
        return "3.5B";
    }

    @Override
    public String Citizens() {
        return "Indians";
    }
}
