public class InterfaceDemoTask3 {

public static void main(String[] args)
{
    String Name = String.valueOf(args[0]);

    if(Name.equals("India"))
    {
        India i = new India();
        System.out.println(i.Citizens());
        System.out.println(i.Population());
    }
    else if(Name.equals("Africa"))
    {
        Africa a = new Africa();
        System.out.println(a.Citizens());
        System.out.println(a.Population());
    }
}
}
