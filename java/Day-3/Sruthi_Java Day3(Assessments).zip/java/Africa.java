public class Africa implements Country{
    @Override
    public String Population() {
        return "6.5B";
    }

    @Override
    public String Citizens() {
        return "Africans";
    }
}
